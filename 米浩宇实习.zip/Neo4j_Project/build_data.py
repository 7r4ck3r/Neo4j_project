from py2neo import Graph, Node, Relationship
import pandas as pd

# 设置Neo4j连接（请替换为你的Neo4j地址、用户名和密码）
graph = Graph("bolt://localhost:7687", auth=("neo4j", "Mihaoyu0518"))

# 读取CSV文件
df = pd.read_csv("新.csv")

# 创建节点和关系
for _, row in df.iterrows():
    # 创建或获取实体1的节点
    entity1 = Node(row['实体1类型'], name=row['实体1文本'])
    graph.merge(entity1, row['实体1类型'], "name")  # merge确保不重复创建

    # 创建或获取实体2的节点
    entity2 = Node(row['实体2类型'], name=row['实体2文本'])
    graph.merge(entity2, row['实体2类型'], "name")  # merge确保不重复创建

    # 创建关系
    relation = Relationship(entity1, row['关系'], entity2)
    graph.merge(relation)  # merge确保关系不重复创建

print("数据已成功导入 Neo4j")
