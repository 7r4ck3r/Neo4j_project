import pandas as pd

# 1. 读取 CSV 文件
file_path = "./data/triples.csv"  # 请替换为您的文件路径
df = pd.read_csv(file_path)

# 2. 提取实体及其对应类型
entities_with_types = pd.concat([
    df[['entity1', 'entity_type1']].rename(columns={'entity1': '实体', 'entity_type1': '类型'}),
    df[['entity2', 'entity_type2']].rename(columns={'entity2': '实体', 'entity_type2': '类型'})
])

# 3. 去重处理
unique_entities = entities_with_types.drop_duplicates()

# 4. 将实体和类型写入 txt 文件，实体和类型中间用空格隔开
output_file = "entities.txt"
with open(output_file, "w", encoding="utf-8") as f:
    for _, row in unique_entities.iterrows():
        f.write(f"{row['实体']}@{row['类型']}\n")

# 5. 打印实体总数（可选）
print("总实体数量:", len(unique_entities))
print(f"实体及类型已保存至 {output_file}")
