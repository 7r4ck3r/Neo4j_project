from py2neo import Graph
import re

# 连接到 Neo4j 数据库
graph = Graph("bolt://localhost:7687", auth=("neo4j", "Mihaoyu0518"))



# 从文件中加载实体列表
# 从 entities.txt 中加载实体及其类型
def load_entities_with_types(file_path):
    entity_type_dict = {}
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                entity, entity_type = line.strip().split("@")  # 分隔实体和类型
                entity_type_dict[entity] = entity_type  # 将实体映射到其类型
            except ValueError:
                continue  # 跳过格式不正确的行
    return entity_type_dict


# 加载实体列表
entity_list = load_entities_with_types("entities.txt")
entity_pattern = "|".join(map(re.escape, entity_list))  # 创建一个正则表达式模式，用于匹配实体


# 问答系统主函数
def answer_question(question):
    # 尝试识别实体和关系
    entity_match = re.search(entity_pattern, question)  # 匹配问题中的实体
    relation_match = re.search("|".join(relation_map.keys()), question)

    if entity_match and relation_match:
        entity = entity_match.group(0)
        relation = relation_map[relation_match.group(0)]
        return query_relationship(entity, relation)
    else:
        return "抱歉，我无法理解您的问题。请尝试询问更具体的问题。"


# 查询函数
def query_relationship(entity, relation):
    query = f"""
    MATCH (s:Entity {{name: $entity}})-[:{relation}]->(o:Entity)
    RETURN o.name AS result
    """
    result = graph.run(query, entity=entity).data()

    if result:
        results = [record["result"] for record in result]
        return f"{entity} 的 '{relation}' 包括：" + "、".join(results)
    else:
        return f"未找到 {entity} 的 '{relation}' 信息。"


# 示例测试
question = "箱体的缺陷项目有哪些？"
print(answer_question(question))

question = "小盒密封度的计量单位是什么？"
print(answer_question(question))
