from flask import Flask, request, jsonify, session, render_template, redirect, url_for
from py2neo import Graph
import re
import hashlib
from difflib import get_close_matches
from zhipuai import ZhipuAI

app = Flask(__name__)
app.secret_key = "qwer"  # 用于存储会话

graph = Graph("bolt://localhost:7687", auth=("neo4j", "Mihaoyu0518"))  # 连接到 Neo4j 数据库

# 用户文件路径
USER_FILE = "users.txt"

# 关系关键词映射
relation_map = {'性别': '性别', '年龄': '年龄', '分为': '分为', '热量原则': '热量原则', '分期': '分期', '蛋白质原则': '蛋白质原则', '脂肪原则': '脂肪原则', '钠原则': '钠原则', '膳食纤维': '膳食纤维', '是指': '是指', '钙原则': '钙原则', '临床表现': '临床表现', '备注': '备注', '病因': '病因', '注意事项': '注意事项', '疾病诊断': '疾病诊断', '治疗方式': '治疗方式', '合并症': '合并症', '钾原则': '钾原则', '磷原则': '磷原则', '体型': '体型', '代谢状态': '代谢状态', '实验室检查': '实验室检查', '用药': '用药', '营养评价': '营养评价', '评估方法': '评估方法', '营养状态': '营养状态', '运动评价': '运动评价'}


# 模糊匹配阈值
MATCH_THRESHOLD = 0.6

# 加密密码
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# 保存用户到文件
def save_user(username, password):
    with open(USER_FILE, "a", encoding="utf-8") as f:
        f.write(f"{username}@{hash_password(password)}\n")

# 加载用户文件
def load_users():
    users = {}
    try:
        with open(USER_FILE, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    username, hashed_password = line.strip().split("@")
                    users[username] = hashed_password
                except ValueError:
                    continue  # 跳过格式不正确的行
    except FileNotFoundError:
        pass  # 如果文件不存在，则返回空字典
    return users

# 从 entities.txt 中加载实体及其类型
def load_entities_with_types(file_path):
    entity_type_dict = {}
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                entity, entity_type = line.strip().split("@")  # 分隔实体和类型
                entity_type_dict[entity] = entity_type  # 将实体映射到其类型
            except ValueError:
                continue  # 跳过格式不正确的行
    return entity_type_dict

# 加载实体及类型
entity_type_dict = load_entities_with_types("entities.txt")

# 构建实体正则模式
entity_pattern = "|".join(re.escape(entity) for entity in entity_type_dict.keys())
relation_pattern = "|".join(re.escape(key) for key in relation_map.keys())  # 匹配关系

# 模糊匹配函数
def fuzzy_match(word, choices, threshold=MATCH_THRESHOLD):
    matches = get_close_matches(word, choices, n=1, cutoff=threshold)
    return matches[0] if matches else None

# 查询 Neo4j 函数（带有模糊匹配）
def query_relationship(entity, relation, label):
    print(f"查询参数 - 实体: {entity}, 关系: {relation}, 标签: {label}")

    # 使用参数化查询避免注入攻击
    query = """
    MATCH (s:`{label}`)-[r]->(o)
    WHERE s.name =~ $entity AND type(r) =~ $relation
    RETURN o.name AS result
    """.format(label=label)
    result = graph.run(query, entity=f'(?i).*{entity}.*', relation=f'(?i).*{relation}.*').data()
    print(result)

    if result:
        results = [record["result"] for record in result]
        final_answer = f"{entity}的 '{relation}'是：" + "、".join(results)
        print(final_answer)
        return enhance_answer_with_model(final_answer)
    else:
        return f"未找到 {entity} 的 '{relation}' 信息。"


def enhance_answer_with_model(answer):
    client = ZhipuAI(api_key="cf663ae46e2d401b931c63e1e21c2847.Rfr8O9HUu0UHvEth")  # 请填写您自己的APIKey
    try:
        response = client.chat.completions.create(
            model="glm-4-flash",
            messages=[
                {
                    "role": "user",
                    "content": f"请润色和扩充以下内容，不超过100字，使其表达更加流畅和自然：\n{answer}"
                }
            ],
        )
        # 打印 API 响应结果
        print("API Response:", response)

        # 从响应中获取润色后的内容
        if response and len(response.choices) > 0:
            glm_answer = response.choices[0].message.content
            print("润色后的答案:", glm_answer)
            return glm_answer

    except Exception as e:
        print(f"调用润色 API 时发生错误: {e}")

    return answer


# 处理问答请求（增加模糊匹配逻辑）
@app.route("/ask", methods=["POST"])
def ask_question():
    question = request.form.get("question")

    # 使用实体正则表达式在问题中查找实体
    entity_match = re.search(entity_pattern, question)
    if entity_match:
        entity = entity_match.group(0)
        label = entity_type_dict.get(entity, 'Entity')

        # 使用模糊匹配关系类型
        relation_match = re.search(relation_pattern, question)
        relation = relation_match.group(0) if relation_match else None

        # 使用模糊匹配找到最接近的关系
        if relation:
            relation_fuzzy = fuzzy_match(relation, relation_map.keys())
            if relation_fuzzy:
                relation = relation_map[relation_fuzzy]  # 将关系映射到标准名称
                # 查询 Neo4j 获取关系的结果
                answer = query_relationship(entity, relation, label)
            else:
                answer = f"未识别出相似的关系类型，无法查询 {entity} 的信息。"
        else:
            answer = f"未识别出关系类型，无法查询 {entity} 的信息。"
    else:
        answer = "未识别出实体，无法查询相关信息。"

    # 保存问答记录到 session
    if "chat_history" not in session:
        session["chat_history"] = []
    session["chat_history"].append({"question": question, "answer": answer})

    return jsonify({"question": question, "answer": answer})

# 注册页面
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        confirm_password = request.form.get("confirm_password")

        if not username or not password:
            return jsonify({"status": "error", "message": "用户名和密码不能为空"}), 400
        if password != confirm_password:
            return jsonify({"status": "error", "message": "两次输入的密码不一致"}), 400

        users = load_users()
        if username in users:
            return jsonify({"status": "error", "message": "用户名已存在"}), 400

        save_user(username, password)
        return redirect(url_for('login'))  # 注册成功后跳转到登录页面
    return render_template("register.html")

# 登录页面
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if not username or not password:
            return jsonify({"status": "error", "message": "用户名和密码不能为空"}), 400

        users = load_users()
        if username in users and users[username] == hash_password(password):
            session["username"] = username
            return redirect(url_for('index'))  # 登录成功后跳转到问答系统界面
        else:
            return jsonify({"status": "error", "message": "用户名或密码错误"}), 400
    return render_template("login.html")

# 注销功能
@app.route("/logout", methods=["POST"])
def logout():
    session.pop("username", None)
    return redirect(url_for('login'))  # 注销后跳转到登录页面

# 问答系统页面
@app.route("/")
def index():
    if "username" not in session:
        return redirect(url_for('login'))  # 未登录时跳转到登录页面
    chat_history = session.get("chat_history", [])
    return render_template("index.html", chat_history=chat_history, username=session["username"])

# 清除历史记录
@app.route("/clear", methods=["POST"])
def clear_history():
    session.pop("chat_history", None)
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(debug=True)
