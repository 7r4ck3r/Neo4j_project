from py2neo import Graph
import openpyxl

# 连接到Neo4j
graph = Graph('bolt://localhost:7687',auth=('neo4j','Mihaoyu0518'))

# 创建节点
def create_nodes(file="triples.xlsx"):

    # 打开triples.xlsx
    wb = openpyxl.load_workbook(file)
    sheet = wb['Sheet1']

    # 遍历创建节点
    #A：头实体类型 B：头实体 C：关系 D：尾实体类型 E：尾实体
    print("creating nodes .......")
    index = 2
    while sheet['A' + str(index)].value != None:

        print("index: " + str(index))

        head_type = sheet['A' + str(index)].value
        head = sheet['B' + str(index)].value
        tail_type = sheet['D' + str(index)].value
        tail = sheet['E' + str(index)].value

        try:
            # 创建头节点
            res_head = graph.run('match(p:' + head_type + ') where p.name="' + str(head) + '"return p')
            if list(res_head) == []:
                graph.run('create(:' + head_type + '{name:"' + str(head) + '"})')
            # 创建尾节点
            res_tail = graph.run('match(p:' + tail_type + ') where p.name="' + str(tail) + '"return p')
            if list(res_tail) == []:
                graph.run('create(:' + tail_type + '{name:"' + str(tail) + '"})')

            index += 1
        except:
            index += 1
            continue
    print("nodes created.\n")

# 创建连接
def create_links(file="triples.xlsx"):

    # 打开triples.xlsx
    wb = openpyxl.load_workbook(file)
    sheet = wb['Sheet1']

    # 遍历创建连接
    print("creating links .......")
    index = 2
    while sheet['A' + str(index)].value != None:

        print("index: " + str(index))

        head_type = sheet['A' + str(index)].value
        head = sheet['B' + str(index)].value
        tail_type = sheet['D' + str(index)].value
        tail = sheet['E' + str(index)].value

        relation = sheet['C' + str(index)].value

        try:
            res_relation = graph.run('match(:' + head_type + '{name:"' + str(head) + '"})-[r]->(:' + \
                                     tail_type + '{name:"' + str(tail) + '"}) return type(r)')
            if relation not in str(res_relation):
                graph.run('match(a:' + head_type + '), (b:' + tail_type + ') where a.name="' + str(head) + '" and b.name="' + str(
                    tail) + '" create (a)-[r:' + relation + ']->(b)')

            index += 1
        except:
            index += 1
            continue
    print("links created.\n")

# 删除所有节点
def delete_nodes():
    print("deleting nodes .......")
    graph.run("match (n) detach delete n")
    print("nodes deleted.\n")

if __name__ == '__main__':
    delete_nodes()
    create_nodes()
    create_links()