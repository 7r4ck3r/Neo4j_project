# import pandas as pd
#
# # 1. 加载 Excel 文件到 DataFrame
# file_path = "关系.csv"  # 替换为您的文件路径
# df = pd.read_csv(file_path)
#
# # 2. 提取 'P' 列，并去重统计
# unique_relations = df['关系'].unique()  # 提取唯一值
# num_unique_relations = len(unique_relations)  # 统计唯一关系数量
#
# # 3. 输出结果
# print("唯一关系列表:", unique_relations)
# print("唯一关系个数:", num_unique_relations)
#
#


import pandas as pd

# 1. 加载 CSV 文件到 DataFrame
file_path = "./data/triples.csv"  # 替换为您的文件路径
df = pd.read_csv(file_path)

# 2. 提取 '关系' 列，并去重
unique_relations = df['relation'].unique()  # 提取唯一值

# 3. 构造 relation_map 字典
relation_map = {relation: relation for relation in unique_relations}

# 4. 输出结果
print("relation_map =", relation_map)
